A leitura do grafo não orientado deve considerar a seguinte ordem das informação:
Linha 1: n: número de nós - Com Ids marcados de 0 a n-1
Demais linhas: i j w - sendo i e j vértices da aresta (i,j) e w o peso da aresta.
